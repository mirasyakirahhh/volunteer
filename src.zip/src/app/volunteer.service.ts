import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {environment} from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VolunteerService {
  baseUrl:any =environment.baseURL;

  constructor(private http:HttpClient) { }

  getvolunteer(){
    return this.http.get(this.baseUrl);
  }

  addvolunteer(data:any){
    return this.http.post(this.baseUrl, data);
  }

  getAllvolunteer(){
    return this.http.get(this.baseUrl);
  }

  deletevolunteer(id:any){
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  getvolunteerById(id:any){
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  updatevolunteerData(id:any, data:any){
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }
}
