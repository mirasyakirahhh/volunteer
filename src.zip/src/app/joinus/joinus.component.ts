import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JoiningService } from '../joining.service';

@Component({
  selector: 'app-joinus',
  templateUrl: './joinus.component.html',
  styleUrls: ['./joinus.component.css']
})
export class JoinusComponent implements OnInit {
  submit:any = FormGroup;
  id:any = 7;
    constructor(private FormBuilder:FormBuilder, private router:Router, private joiningserv:JoiningService) { }

    ngOnInit(): void {
      this.submit = this.FormBuilder.group({
        activities:['', Validators.required],
        date:['', Validators.required],
        name:['', Validators.required],
        email:['', Validators.compose([Validators.required, Validators.email])],
        phonenumber:['', Validators.required]

      })
    }

    submitForm(data:any){
      console.log(data);
      let dataToPass = {
        activities:data.activities,
        date:data.date,
        email:data.email,
        phonenumber:data.phonenumber,
        name:data.name,
        id:this.id++
      }

      this.joiningserv.addjoining(dataToPass).subscribe((data:any)=>{
        console.log(data);
      })

      this.router.navigate(['reminder']);

  }

  logout(){
    localStorage.clear();
    this.router.navigate(['login']);
  }





}

