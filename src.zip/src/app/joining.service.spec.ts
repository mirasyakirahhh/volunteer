import { TestBed } from '@angular/core/testing';

import { JoiningService } from './joining.service';

describe('JoiningService', () => {
  let service: JoiningService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JoiningService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
