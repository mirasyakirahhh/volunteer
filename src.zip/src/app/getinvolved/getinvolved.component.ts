import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { VolunteerService } from '../volunteer.service';

@Component({
  selector: 'app-getinvolved',
  templateUrl: './getinvolved.component.html',
  styleUrls: ['./getinvolved.component.css']
})
export class GetinvolvedComponent implements OnInit {
  volunteerList:any =[];
  constructor(private volunterserv:VolunteerService, private router:Router) { }

  ngOnInit(): void {
    this.volunterserv.getvolunteer().subscribe((data:any)=>{
      this.volunteerList = data;
    })
  }

  logout(){
    localStorage.clear();
    this.router.navigate(['login']);
  }
}

