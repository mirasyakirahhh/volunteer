import { Component, OnInit } from '@angular/core';
import { JoiningService } from '../joining.service';

import { Router } from '@angular/router';


@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {

  constructor(private router:Router,private joiningserv: JoiningService) { }
  joining: any = [];

  ngOnInit(): void {
  this.joiningserv.getAlljoining().subscribe((data:any)=>{
      console.log(data);
      this.joining = data;
    });
  }
  deletejoining(joining_id: any) {
    this.joiningserv.deletejoining(joining_id)
    .subscribe((_result: any) => {
      //console.log(result);
      this.ngOnInit();
    });
  }


  logout(){
    localStorage.clear();
    this.router.navigate(['login']);
  }
}



