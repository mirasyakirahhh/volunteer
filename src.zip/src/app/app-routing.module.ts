import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { DasboardComponent } from './dasboard/dasboard.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RegisterComponent } from './register/register.component';
import { JoinusComponent } from './joinus/joinus.component';
import { GetinvolvedComponent } from './getinvolved/getinvolved.component';
import { AboutComponent } from './about/about.component';
import { FaqComponent } from './faq/faq.component';
import { ReminderComponent } from './reminder/reminder.component';
import { EditComponent } from './edit/edit.component';


const routes: Routes = [
  {
    path: '',
    redirectTo:'login', pathMatch: 'full'
  },
  {path: 'navbar', component:NavbarComponent},
  {path: 'home', component:DasboardComponent, canActivate:[AuthGuard]},
  {path: 'login', component:LoginComponent},
  {path: 'register', component:RegisterComponent},
  { path: "joinus", component:JoinusComponent },
  { path: 'getinvolved', component:GetinvolvedComponent},
  { path: 'about', component:AboutComponent },
  { path: 'faq', component:FaqComponent},
  {path: "reminder", component:ReminderComponent},
  {path: "edit/:id", component:EditComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
