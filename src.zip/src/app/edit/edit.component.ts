import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { JoiningService } from '../joining.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private route: Router ,private joining: JoiningService, private router: ActivatedRoute) { }

  editjoining = new FormGroup( {
    activities: new FormControl(''),
    name: new FormControl(''),
    date: new FormControl(''),
    email: new FormControl(''),
    phonenumber: new FormControl(''),
  });

  message: boolean=false;
  ngOnInit(): void {
      // console.log( this.router.snapshot.params['id']);
      this.joining.getjoiningById(this.router.snapshot.params['id'] ).subscribe((result:any) => {
        console.log(result);
      this.editjoining = new FormGroup({
        activities: new FormControl(result['activities']),
        name: new FormControl(result['name']),
        date: new FormControl(result['date']),
        email: new FormControl(result['email']),
        phonenumber: new FormControl(result['phonenumber'])
      });
    });
  }

  UpdateData() {
    console.log(this.editjoining.value);

    this.joining.updatejoiningData(this.router.snapshot.params['id'], this.editjoining.value).subscribe((result:any) =>{
      console.log(result);
      this.message = true;
    });
  }



  removeMessage() {
    this.message = false;
  }

  logout(){
    localStorage.clear();
    this.route.navigate(['login']);
  }

}
