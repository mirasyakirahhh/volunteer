import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {environment} from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class JoiningService {
  newUrl:any =environment.newURL;

  constructor(private http:HttpClient) { }

  getjoining(){
    return this.http.get(this.newUrl);
  }

  addjoining(data:any){
    return this.http.post(this.newUrl, data);
  }

  getAlljoining(){
    return this.http.get(this.newUrl);
  }

  deletejoining(id:any){
    return this.http.delete(`${this.newUrl}/${id}`);
  }

  getjoiningById(id:number){
    return this.http.get(`${this.newUrl}/${id}`);
  }

  updatejoiningData(id:number, data:any){
    return this.http.put(`${this.newUrl}/${id}`, data);
  }
}
