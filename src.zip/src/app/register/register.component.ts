import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { VolunteerService } from '../volunteer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
register:any = FormGroup;
id:any = 19;
  constructor(private FormBuilder:FormBuilder, private router:Router, private volunteerserv:VolunteerService) { }

  message: boolean=false;
  ngOnInit(): void {
    this.register = this.FormBuilder.group({
      username:['', Validators.required],
      email:['', Validators.compose([Validators.required, Validators.email])],
      phoneNo:['', Validators.required],
      password:['', Validators.required]

    })
  }

  registerForm(data:any){
    console.log(data);
    let dataToPass = {
      username:data.username,
      email:data.email,
      phoneNo:data.phoneNo,
      password:data.password,
      id:this.id++
    }

    this.volunteerserv.addvolunteer(dataToPass).subscribe((data:any)=>{
      console.log(data);
    })
  }

  updateMessage() {
    this.message = false;
  }
  gotToLogin(){
    this.router.navigate(['login']);
  }
}
